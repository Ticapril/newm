<!doctype html>
<html lang="pt-br">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" integrity="sha384-WJUUqfoMmnfkBLne5uxXj+na/c7sesSJ32gI7GfCk4zO4GthUKhSEGyvQ839BC51" crossorigin="anonymous">
    <title>Newm Project</title>
  </head>
  <body class="bg-light">
    <div class="container rounded-3">
      <div class="container bg-dark  text-light  mb-3 p-5 rounded-3 ">
        <h1 class="display-5">Listagem Clientes</h1>
        <p>Projeto Newm para vaga de Estágio Desenvolvimento Web</p>
      </div>